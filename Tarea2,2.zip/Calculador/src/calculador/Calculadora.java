package calculador;

/**
 *
 * @author Braulio
 */
public class Calculadora {

    public double sumar(double v1, double v2) {
        return v1 + v2;
    }

    public double sumar(double v1, double v2, double v3) {
        return v1 + v2 + v3;
    }

    public double sumar(double v1, double v2, double v3, double v4) {
        return v1 + v2 + v3 + v4;
    }

    public double restar(double v1, double v2) {
        return v1 - v2;
    }

    public double restar(double v1, double v2, double v3) {
        return v1 - v2 - v3;
    }

    public double restar(double v1, double v2, double v3, double v4) {
        return v1 - v2 - v3 - v4;
    }

    public double multi(double v1, double v2) {
        return v1 * v2;
    }

    public double multi(double v1, double v2, double v3) {
        return v1 * v2 * v3;
    }

    public double multi(double v1, double v2, double v3, double v4) {
        return v1 * v2 * v3 * v4;
    }

    public double div(double v1, double v2) {
        return v1 / v2;
    }

    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        System.out.println(calc.sumar(4, 6));
        System.out.println(calc.restar(4, 6, 8));
        System.out.println(calc.multi(4, 6, 8, 7));
    }

}
